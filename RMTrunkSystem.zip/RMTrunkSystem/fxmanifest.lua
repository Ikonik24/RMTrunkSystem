fx_version 'cerulean'
games { 'gta5' }

author 'RM'
description 'RM Trunk'
version '1.0.0'

client_scripts {
    'client.lua'
}